//
//  WBBrowserSDK.h
//  WBBrowser
//
//  Created by jinrun on 2020/7/17.
//  Copyright © 2020 jinrun. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WBBrowserConfigObject : NSObject
@property (nonatomic,strong,nullable)UIImage *vcBackImage; //返回按钮图片
/*默认是present的方式显示热门H5页面，如果需要push方式需要提供一个UINavigationController 来push出热门H5的页面*/
@property (nonatomic,strong,nullable)UINavigationController *pushRootVc;
@end


@interface WBBrowserSDK : NSObject

@property (nonatomic,strong,nonnull)NSString *appKey;
@property (nonatomic,strong,nonnull)NSString *apple_id;

+ (instancetype)sharedManager;

/*
注册，全局只需要注册一次
appkey：微博开发平台注册申请的appKey
appleId：微博开发平台申请sdk填写的appleId
*/
+ (void)registeredAppkey:(NSString * __nonnull)appkey withAppleId:(NSString * __nonnull)appleId;

/*
 sdkObject 配置显示热门流页面参数
 completion：是否能显示出H5热门页的回调，error不为空时就不能显示H5热门页
 */
+ (void)showBrowserConfigObject:(WBBrowserConfigObject *)sdkObject CompletionHandler:(void(^)(NSError *error))handler;


@end

NS_ASSUME_NONNULL_END
